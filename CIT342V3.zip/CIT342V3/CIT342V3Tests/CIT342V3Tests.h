//
//  CIT342V3Tests.h
//  CIT342V3Tests
//
//  Created by Professor on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface CIT342V3Tests : SenTestCase

@end
