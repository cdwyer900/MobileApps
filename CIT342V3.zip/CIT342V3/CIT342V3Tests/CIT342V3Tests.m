//
//  CIT342V3Tests.m
//  CIT342V3Tests
//
//  Created by Professor on 3/27/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CIT342V3Tests.h"

@implementation CIT342V3Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in CIT342V3Tests");
}

@end
